install
cd rCPU/rCPU/
sudo make install

connect
http://169.254.226.130:8111/

uninstall
sudo make uninstall