/****************************************************************************
** Meta object code from reading C++ file 'globalenumerate.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../SmartHomeDomotic/globalenumerate.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'globalenumerate.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_GlobalEnumerate_t {
    QByteArrayData data[44];
    char stringdata0[602];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GlobalEnumerate_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GlobalEnumerate_t qt_meta_stringdata_GlobalEnumerate = {
    {
QT_MOC_LITERAL(0, 0, 15), // "GlobalEnumerate"
QT_MOC_LITERAL(1, 16, 11), // "E_PlotStyle"
QT_MOC_LITERAL(2, 28, 26), // "PLOT_STYLE_WEATHER_STATION"
QT_MOC_LITERAL(3, 55, 24), // "PLOT_STYLE_ANANLOG_TRACE"
QT_MOC_LITERAL(4, 80, 26), // "PLOT_STYLE_STATISTIC_TRACE"
QT_MOC_LITERAL(5, 107, 28), // "PLOT_STYLE_TEMPERATURE_TRACE"
QT_MOC_LITERAL(6, 136, 25), // "PLOT_STYLE_HUMIDITY_TRACE"
QT_MOC_LITERAL(7, 162, 25), // "PLOT_STYLE_PRESSURE_TRACE"
QT_MOC_LITERAL(8, 188, 18), // "E_TankLiquidInside"
QT_MOC_LITERAL(9, 207, 5), // "WATER"
QT_MOC_LITERAL(10, 213, 3), // "OIL"
QT_MOC_LITERAL(11, 217, 7), // "ECO_OIL"
QT_MOC_LITERAL(12, 225, 16), // "E_TankObjectName"
QT_MOC_LITERAL(13, 242, 5), // "TANK1"
QT_MOC_LITERAL(14, 248, 5), // "TANK2"
QT_MOC_LITERAL(15, 254, 5), // "TANK3"
QT_MOC_LITERAL(16, 260, 5), // "TANK4"
QT_MOC_LITERAL(17, 266, 5), // "TANK5"
QT_MOC_LITERAL(18, 272, 5), // "TANK6"
QT_MOC_LITERAL(19, 278, 16), // "E_HomePageObject"
QT_MOC_LITERAL(20, 295, 10), // "HOMEBME280"
QT_MOC_LITERAL(21, 306, 9), // "HOMETANK1"
QT_MOC_LITERAL(22, 316, 9), // "HOMETANK2"
QT_MOC_LITERAL(23, 326, 9), // "HOMETANK3"
QT_MOC_LITERAL(24, 336, 9), // "HOMETANK4"
QT_MOC_LITERAL(25, 346, 9), // "HOMETANK5"
QT_MOC_LITERAL(26, 356, 9), // "HOMETANK6"
QT_MOC_LITERAL(27, 366, 11), // "HOMESENSOR1"
QT_MOC_LITERAL(28, 378, 11), // "HOMESENSOR2"
QT_MOC_LITERAL(29, 390, 11), // "HOMESENSOR3"
QT_MOC_LITERAL(30, 402, 11), // "HOMESENSOR4"
QT_MOC_LITERAL(31, 414, 11), // "HOMESENSOR5"
QT_MOC_LITERAL(32, 426, 11), // "HOMESENSOR6"
QT_MOC_LITERAL(33, 438, 12), // "HOMEAD1115_1"
QT_MOC_LITERAL(34, 451, 12), // "HOMEAD1115_2"
QT_MOC_LITERAL(35, 464, 15), // "E_ErrorMesseage"
QT_MOC_LITERAL(36, 480, 12), // "ERR_NO_ERROR"
QT_MOC_LITERAL(37, 493, 21), // "ERR_LOW_LEVEL_REACHED"
QT_MOC_LITERAL(38, 515, 14), // "E_StateMachine"
QT_MOC_LITERAL(39, 530, 17), // "STATE_NOT_FOUNDED"
QT_MOC_LITERAL(40, 548, 13), // "STATE_FOUNDED"
QT_MOC_LITERAL(41, 562, 10), // "STATE_INIT"
QT_MOC_LITERAL(42, 573, 16), // "STATE_ON_READING"
QT_MOC_LITERAL(43, 590, 11) // "STATE_READY"

    },
    "GlobalEnumerate\0E_PlotStyle\0"
    "PLOT_STYLE_WEATHER_STATION\0"
    "PLOT_STYLE_ANANLOG_TRACE\0"
    "PLOT_STYLE_STATISTIC_TRACE\0"
    "PLOT_STYLE_TEMPERATURE_TRACE\0"
    "PLOT_STYLE_HUMIDITY_TRACE\0"
    "PLOT_STYLE_PRESSURE_TRACE\0E_TankLiquidInside\0"
    "WATER\0OIL\0ECO_OIL\0E_TankObjectName\0"
    "TANK1\0TANK2\0TANK3\0TANK4\0TANK5\0TANK6\0"
    "E_HomePageObject\0HOMEBME280\0HOMETANK1\0"
    "HOMETANK2\0HOMETANK3\0HOMETANK4\0HOMETANK5\0"
    "HOMETANK6\0HOMESENSOR1\0HOMESENSOR2\0"
    "HOMESENSOR3\0HOMESENSOR4\0HOMESENSOR5\0"
    "HOMESENSOR6\0HOMEAD1115_1\0HOMEAD1115_2\0"
    "E_ErrorMesseage\0ERR_NO_ERROR\0"
    "ERR_LOW_LEVEL_REACHED\0E_StateMachine\0"
    "STATE_NOT_FOUNDED\0STATE_FOUNDED\0"
    "STATE_INIT\0STATE_ON_READING\0STATE_READY"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GlobalEnumerate[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       6,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    6,   38,
       8, 0x0,    3,   50,
      12, 0x0,    6,   56,
      19, 0x0,   15,   68,
      35, 0x0,    2,   98,
      38, 0x0,    5,  102,

 // enum data: key, value
       2, uint(GlobalEnumerate::PLOT_STYLE_WEATHER_STATION),
       3, uint(GlobalEnumerate::PLOT_STYLE_ANANLOG_TRACE),
       4, uint(GlobalEnumerate::PLOT_STYLE_STATISTIC_TRACE),
       5, uint(GlobalEnumerate::PLOT_STYLE_TEMPERATURE_TRACE),
       6, uint(GlobalEnumerate::PLOT_STYLE_HUMIDITY_TRACE),
       7, uint(GlobalEnumerate::PLOT_STYLE_PRESSURE_TRACE),
       9, uint(GlobalEnumerate::WATER),
      10, uint(GlobalEnumerate::OIL),
      11, uint(GlobalEnumerate::ECO_OIL),
      13, uint(GlobalEnumerate::TANK1),
      14, uint(GlobalEnumerate::TANK2),
      15, uint(GlobalEnumerate::TANK3),
      16, uint(GlobalEnumerate::TANK4),
      17, uint(GlobalEnumerate::TANK5),
      18, uint(GlobalEnumerate::TANK6),
      20, uint(GlobalEnumerate::HOMEBME280),
      21, uint(GlobalEnumerate::HOMETANK1),
      22, uint(GlobalEnumerate::HOMETANK2),
      23, uint(GlobalEnumerate::HOMETANK3),
      24, uint(GlobalEnumerate::HOMETANK4),
      25, uint(GlobalEnumerate::HOMETANK5),
      26, uint(GlobalEnumerate::HOMETANK6),
      27, uint(GlobalEnumerate::HOMESENSOR1),
      28, uint(GlobalEnumerate::HOMESENSOR2),
      29, uint(GlobalEnumerate::HOMESENSOR3),
      30, uint(GlobalEnumerate::HOMESENSOR4),
      31, uint(GlobalEnumerate::HOMESENSOR5),
      32, uint(GlobalEnumerate::HOMESENSOR6),
      33, uint(GlobalEnumerate::HOMEAD1115_1),
      34, uint(GlobalEnumerate::HOMEAD1115_2),
      36, uint(GlobalEnumerate::ERR_NO_ERROR),
      37, uint(GlobalEnumerate::ERR_LOW_LEVEL_REACHED),
      39, uint(GlobalEnumerate::STATE_NOT_FOUNDED),
      40, uint(GlobalEnumerate::STATE_FOUNDED),
      41, uint(GlobalEnumerate::STATE_INIT),
      42, uint(GlobalEnumerate::STATE_ON_READING),
      43, uint(GlobalEnumerate::STATE_READY),

       0        // eod
};

void GlobalEnumerate::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject GlobalEnumerate::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_GlobalEnumerate.data,
      qt_meta_data_GlobalEnumerate,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *GlobalEnumerate::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GlobalEnumerate::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_GlobalEnumerate.stringdata0))
        return static_cast<void*>(const_cast< GlobalEnumerate*>(this));
    return QObject::qt_metacast(_clname);
}

int GlobalEnumerate::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_END_MOC_NAMESPACE
