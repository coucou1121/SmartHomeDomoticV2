/****************************************************************************
** Meta object code from reading C++ file 'customplotitem.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../SmartHomeDomotic/customplotitem.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'customplotitem.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_CustomPlotItem_t {
    QByteArrayData data[42];
    char stringdata0[521];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CustomPlotItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CustomPlotItem_t qt_meta_stringdata_CustomPlotItem = {
    {
QT_MOC_LITERAL(0, 0, 14), // "CustomPlotItem"
QT_MOC_LITERAL(1, 15, 12), // "graphClicked"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 21), // "QCPAbstractPlottable*"
QT_MOC_LITERAL(4, 51, 9), // "plottable"
QT_MOC_LITERAL(5, 61, 14), // "onCustomReplot"
QT_MOC_LITERAL(6, 76, 20), // "updateCustomPlotSize"
QT_MOC_LITERAL(7, 97, 35), // "_recievedRefreshDataTemperatu..."
QT_MOC_LITERAL(8, 133, 10), // "updatePlot"
QT_MOC_LITERAL(9, 144, 10), // "setupStyle"
QT_MOC_LITERAL(10, 155, 28), // "GlobalEnumerate::E_PlotStyle"
QT_MOC_LITERAL(11, 184, 9), // "plotstyle"
QT_MOC_LITERAL(12, 194, 9), // "nbOfTrace"
QT_MOC_LITERAL(13, 204, 15), // "setupGraphLabel"
QT_MOC_LITERAL(14, 220, 11), // "traceNumber"
QT_MOC_LITERAL(15, 232, 9), // "titleText"
QT_MOC_LITERAL(16, 242, 20), // "setupTraceIsSelected"
QT_MOC_LITERAL(17, 263, 9), // "isVisible"
QT_MOC_LITERAL(18, 273, 8), // "addPoint"
QT_MOC_LITERAL(19, 282, 11), // "graphNumber"
QT_MOC_LITERAL(20, 294, 1), // "x"
QT_MOC_LITERAL(21, 296, 1), // "y"
QT_MOC_LITERAL(22, 298, 9), // "addYValue"
QT_MOC_LITERAL(23, 308, 11), // "valueGraph0"
QT_MOC_LITERAL(24, 320, 11), // "valueGraph1"
QT_MOC_LITERAL(25, 332, 11), // "valueGraph2"
QT_MOC_LITERAL(26, 344, 11), // "valueGraph3"
QT_MOC_LITERAL(27, 356, 11), // "valueGraph4"
QT_MOC_LITERAL(28, 368, 11), // "valueGraph5"
QT_MOC_LITERAL(29, 380, 19), // "settingTriggerValue"
QT_MOC_LITERAL(30, 400, 10), // "tickAsDate"
QT_MOC_LITERAL(31, 411, 10), // "tickNumber"
QT_MOC_LITERAL(32, 422, 14), // "isTheFirstData"
QT_MOC_LITERAL(33, 437, 19), // "clearGraphAndValues"
QT_MOC_LITERAL(34, 457, 6), // "replot"
QT_MOC_LITERAL(35, 464, 6), // "resize"
QT_MOC_LITERAL(36, 471, 19), // "replotWithSavedData"
QT_MOC_LITERAL(37, 491, 4), // "year"
QT_MOC_LITERAL(38, 496, 5), // "month"
QT_MOC_LITERAL(39, 502, 3), // "day"
QT_MOC_LITERAL(40, 506, 8), // "setRange"
QT_MOC_LITERAL(41, 515, 5) // "range"

    },
    "CustomPlotItem\0graphClicked\0\0"
    "QCPAbstractPlottable*\0plottable\0"
    "onCustomReplot\0updateCustomPlotSize\0"
    "_recievedRefreshDataTemperaturePlot\0"
    "updatePlot\0setupStyle\0"
    "GlobalEnumerate::E_PlotStyle\0plotstyle\0"
    "nbOfTrace\0setupGraphLabel\0traceNumber\0"
    "titleText\0setupTraceIsSelected\0isVisible\0"
    "addPoint\0graphNumber\0x\0y\0addYValue\0"
    "valueGraph0\0valueGraph1\0valueGraph2\0"
    "valueGraph3\0valueGraph4\0valueGraph5\0"
    "settingTriggerValue\0tickAsDate\0"
    "tickNumber\0isTheFirstData\0clearGraphAndValues\0"
    "replot\0resize\0replotWithSavedData\0"
    "year\0month\0day\0setRange\0range"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CustomPlotItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  119,    2, 0x08 /* Private */,
       5,    0,  122,    2, 0x08 /* Private */,
       6,    0,  123,    2, 0x08 /* Private */,
       7,    0,  124,    2, 0x08 /* Private */,
       8,    0,  125,    2, 0x08 /* Private */,

 // methods: name, argc, parameters, tag, flags
       9,    2,  126,    2, 0x02 /* Public */,
      13,    2,  131,    2, 0x02 /* Public */,
      16,    2,  136,    2, 0x02 /* Public */,
      18,    3,  141,    2, 0x02 /* Public */,
      22,   10,  148,    2, 0x02 /* Public */,
      22,    9,  169,    2, 0x22 /* Public | MethodCloned */,
      22,    8,  188,    2, 0x22 /* Public | MethodCloned */,
      22,    7,  205,    2, 0x22 /* Public | MethodCloned */,
      22,    6,  220,    2, 0x22 /* Public | MethodCloned */,
      22,    5,  233,    2, 0x22 /* Public | MethodCloned */,
      22,    4,  244,    2, 0x22 /* Public | MethodCloned */,
      22,    3,  253,    2, 0x22 /* Public | MethodCloned */,
      33,    0,  260,    2, 0x02 /* Public */,
      34,    1,  261,    2, 0x02 /* Public */,
      36,    3,  264,    2, 0x02 /* Public */,
      40,    1,  271,    2, 0x02 /* Public */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // methods: parameters
    QMetaType::Void, 0x80000000 | 10, QMetaType::UChar,   11,   12,
    QMetaType::Void, QMetaType::UChar, QMetaType::QString,   14,   15,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   14,   17,
    QMetaType::Void, QMetaType::Int, QMetaType::Double, QMetaType::Double,   19,   20,   21,
    QMetaType::Void, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::Bool, QMetaType::UChar, QMetaType::Bool,   23,   24,   25,   26,   27,   28,   29,   30,   31,   32,
    QMetaType::Void, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::Bool, QMetaType::UChar,   23,   24,   25,   26,   27,   28,   29,   30,   31,
    QMetaType::Void, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::Bool,   23,   24,   25,   26,   27,   28,   29,   30,
    QMetaType::Void, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal,   23,   24,   25,   26,   27,   28,   29,
    QMetaType::Void, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal,   23,   24,   25,   26,   27,   28,
    QMetaType::Void, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal,   23,   24,   25,   26,   27,
    QMetaType::Void, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal,   23,   24,   25,   26,
    QMetaType::Void, QMetaType::QReal, QMetaType::QReal, QMetaType::QReal,   23,   24,   25,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void, QMetaType::UShort, QMetaType::UChar, QMetaType::UChar,   37,   38,   39,
    QMetaType::Void, QMetaType::ULongLong,   41,

       0        // eod
};

void CustomPlotItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        CustomPlotItem *_t = static_cast<CustomPlotItem *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->graphClicked((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1]))); break;
        case 1: _t->onCustomReplot(); break;
        case 2: _t->updateCustomPlotSize(); break;
        case 3: _t->_recievedRefreshDataTemperaturePlot(); break;
        case 4: _t->updatePlot(); break;
        case 5: _t->setupStyle((*reinterpret_cast< GlobalEnumerate::E_PlotStyle(*)>(_a[1])),(*reinterpret_cast< quint8(*)>(_a[2]))); break;
        case 6: _t->setupGraphLabel((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 7: _t->setupTraceIsSelected((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 8: _t->addPoint((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const double(*)>(_a[2])),(*reinterpret_cast< const double(*)>(_a[3]))); break;
        case 9: _t->addYValue((*reinterpret_cast< qreal(*)>(_a[1])),(*reinterpret_cast< qreal(*)>(_a[2])),(*reinterpret_cast< qreal(*)>(_a[3])),(*reinterpret_cast< qreal(*)>(_a[4])),(*reinterpret_cast< qreal(*)>(_a[5])),(*reinterpret_cast< qreal(*)>(_a[6])),(*reinterpret_cast< qreal(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< quint8(*)>(_a[9])),(*reinterpret_cast< bool(*)>(_a[10]))); break;
        case 10: _t->addYValue((*reinterpret_cast< qreal(*)>(_a[1])),(*reinterpret_cast< qreal(*)>(_a[2])),(*reinterpret_cast< qreal(*)>(_a[3])),(*reinterpret_cast< qreal(*)>(_a[4])),(*reinterpret_cast< qreal(*)>(_a[5])),(*reinterpret_cast< qreal(*)>(_a[6])),(*reinterpret_cast< qreal(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< quint8(*)>(_a[9]))); break;
        case 11: _t->addYValue((*reinterpret_cast< qreal(*)>(_a[1])),(*reinterpret_cast< qreal(*)>(_a[2])),(*reinterpret_cast< qreal(*)>(_a[3])),(*reinterpret_cast< qreal(*)>(_a[4])),(*reinterpret_cast< qreal(*)>(_a[5])),(*reinterpret_cast< qreal(*)>(_a[6])),(*reinterpret_cast< qreal(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8]))); break;
        case 12: _t->addYValue((*reinterpret_cast< qreal(*)>(_a[1])),(*reinterpret_cast< qreal(*)>(_a[2])),(*reinterpret_cast< qreal(*)>(_a[3])),(*reinterpret_cast< qreal(*)>(_a[4])),(*reinterpret_cast< qreal(*)>(_a[5])),(*reinterpret_cast< qreal(*)>(_a[6])),(*reinterpret_cast< qreal(*)>(_a[7]))); break;
        case 13: _t->addYValue((*reinterpret_cast< qreal(*)>(_a[1])),(*reinterpret_cast< qreal(*)>(_a[2])),(*reinterpret_cast< qreal(*)>(_a[3])),(*reinterpret_cast< qreal(*)>(_a[4])),(*reinterpret_cast< qreal(*)>(_a[5])),(*reinterpret_cast< qreal(*)>(_a[6]))); break;
        case 14: _t->addYValue((*reinterpret_cast< qreal(*)>(_a[1])),(*reinterpret_cast< qreal(*)>(_a[2])),(*reinterpret_cast< qreal(*)>(_a[3])),(*reinterpret_cast< qreal(*)>(_a[4])),(*reinterpret_cast< qreal(*)>(_a[5]))); break;
        case 15: _t->addYValue((*reinterpret_cast< qreal(*)>(_a[1])),(*reinterpret_cast< qreal(*)>(_a[2])),(*reinterpret_cast< qreal(*)>(_a[3])),(*reinterpret_cast< qreal(*)>(_a[4]))); break;
        case 16: _t->addYValue((*reinterpret_cast< qreal(*)>(_a[1])),(*reinterpret_cast< qreal(*)>(_a[2])),(*reinterpret_cast< qreal(*)>(_a[3]))); break;
        case 17: _t->clearGraphAndValues(); break;
        case 18: _t->replot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: _t->replotWithSavedData((*reinterpret_cast< quint16(*)>(_a[1])),(*reinterpret_cast< quint8(*)>(_a[2])),(*reinterpret_cast< quint8(*)>(_a[3]))); break;
        case 20: _t->setRange((*reinterpret_cast< const quint64(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractPlottable* >(); break;
            }
            break;
        }
    }
}

const QMetaObject CustomPlotItem::staticMetaObject = {
    { &QQuickPaintedItem::staticMetaObject, qt_meta_stringdata_CustomPlotItem.data,
      qt_meta_data_CustomPlotItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *CustomPlotItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CustomPlotItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_CustomPlotItem.stringdata0))
        return static_cast<void*>(const_cast< CustomPlotItem*>(this));
    return QQuickPaintedItem::qt_metacast(_clname);
}

int CustomPlotItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickPaintedItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
